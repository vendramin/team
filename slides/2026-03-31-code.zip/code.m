function Factorize_modP(w,P)
h:=#P;
B:=[0^^h];
for i in [1..h] do
    if w mod P[i] eq 0 and w ne 0 then
        B[i]:=Valuation(w,P[i]);
        // //First idea
        // repeat
        //     w:=w div P[i];
        //     B[i]:=B[i]+1;
        // until w mod P[i] ne 0 or w eq 0;
    end if;
end for;
prod:=&*[P[i]^B[i]: i in [1..h]];
w:=w div prod;
//At this point we factorized w modulo the set P 
//and we overwrote w, so in w we have the "remainder" 
//of the factorization modulo P, that is w' 
if w ne 1 then
    B:=[0];
end if;
return B;
end function;

function Dixon(n,v)
P:=PrimesUpTo(v);
//Observe here that Magma puts a restriction on the size
//of the smoothness factor that we can choose, 
//in particular, PrimesUpTo( ) works with integers up to
//2^(30) - 1, because of memory requirements
B:=[];
Z:=[];
j:=1;
repeat
    z:=Random([1..n]);
    w:=z^2 mod n;
    if #Factorize_modP(w,P) gt 1 then
    //if #Factorize_modP(w,P)=1, then w'=1 -> 
    //we must choose another z! 
        B[j]:=Factorize_modP(w,P);
        Z[j]:=z;
        j:=j+1;
    end if;
until #B gt #P;

//This condition guarantees that we find a subset
//of dependent vectors in B

B_bin:=[[GF(2)!B[i][j]:j in [1..#B[i]]]:i in [1..#B]];
M:=Matrix(GF(2),B_bin);
F:=NullspaceMatrix(M);

//This check is interesting but not necessary in this case
// if Nrows(F) eq 0 then
//     return 0;
// end if;

// f:=Eltseq(ChangeRing(F[1],Integers()));
f:=[Eltseq(ChangeRing(F[i],Integers())): i in [1..Nrows(F)]];

for k in [1..#f] do

    // //First idea
    // y:=1;
    // x:=1;
    // for j in [1..#f] do
    //     if f[j] eq 1 then
    //         for t in [1..#B[j]] do
    //             if B[j][t] ne 0 then
    //                 y:=y*P[t]^B[j][t];
    //             end if;
    //         end for;
    //         x:=x*Z[j];
    //     end if;
    // end for;
    // y:=Floor(Sqrt(y));

    //Second idea
    d:=[[f[k][i]*B[i][j]:j in [1..#B[i]]]:i in [1..#B]];

    //Now we have to sum all the first components of 
    //the sequences of d, all the second ones and so on... 
    //To do this we can do some nested for cycle or...

    d:=Transpose(Matrix(d));
    d:=[&+Eltseq(d[i]) div 2:i in [1..Nrows(d)]];
    x:=&*[Z[i]^f[k][i] : i in [1..#Z]];
    y:=&*[P[i]^d[i] : i in [1..#P]];

    if GCD(x-y,n) notin {1,n} then
        return GCD(x-y,n);
    elif GCD(x+y,n) notin {1,n} then
        return GCD(x+y,n);
    end if;

end for;
return 0;
end function;

function Factorization_Dixon(n,v)
z:=[];
K:=[];
i:=1;
error if n eq 0 or v le 2,
    "Error first input must be non-zero and second input must be grater than 2";
if n lt 0 then 
    n:=-n;
end if;
if n eq 1 then
    return [];
end if;
if IsPrime(n) then
    return [<n,1>];
end if;
if IsPrimePower(n) then
    bool,p,e:=IsPrimePower(n);
    return [<p,e>];
end if;
repeat
    f:=Dixon(n,v);
until f ne 0;
z[1]:=n div f;
z[2]:=f;
s:=1;
repeat
    if IsPrime(z[s]) then
        K:=K cat [z[s]];
        z[s]:=1;
        s:=s+1;
    elif IsPrimePower(z[s]) then
        bool,p,e:=IsPrimePower(z[s]);
        K:=K cat [p];
        z[s]:=z[s] div p;
    else
        repeat
            f:=Dixon(z[s],v);
        until f ne 0;
        z:=z cat [z[s] div f] cat [f];
        s:=s+1;
    end if;
until z[#z] eq 1;
K:=Sort(K);
S:=Sort(Setseq(Seqset(K)));
T:=[];
j:=1;
for i in [1..#S] do
    s:=0;
    while j le #K and K[j] eq S[i] do
        j:=j+1;
        s:=s+1;
    end while;
    T[i]:=<S[i],s>;
end for;
return T;
end function;

//Test and time considerations
k:=0;
for i in [1..50] do
    if Dixon(3499*2593,50) eq 0 then
        k:=k+1;
    end if;
end for;
k;
times:=[];
for i in [1..50] do
    t:=Cputime();
    f:=Dixon(3499*2593,50);
    times[i]:=Cputime(t);
end for;
&+times/50;