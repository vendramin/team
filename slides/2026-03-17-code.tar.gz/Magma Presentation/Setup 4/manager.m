socketA := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10000);
socketB := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10001);
socketC := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10002);

Nmr_workers := 8;

MySecondFunction := function(n);
	tasks := [1..n];
	for i in [1..Nmr_workers] do
		command := "magma workerA.m > logs/workerA-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output1 := DistributedManager(socketA,tasks);
	for s in output1 do
		print s;
	end for;
	
	for i in [1..Nmr_workers] do
		command := "magma workerB.m > logs/workerB-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output2 := DistributedManager(socketB,tasks);
	for s in output2 do
		print s;
	end for;
	
	for i in [1..Nmr_workers] do
		command := "magma workerC.m > logs/workerC-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output3 := DistributedManager(socketC,tasks);
	for s in output3 do
		print s;
	end for;
	return "done";
end function;
