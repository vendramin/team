MyFirstFunction := function(t);
	System("sleep " cat IntegerToString(t));
	return "Hello Mars!";
end function;

host := "andrew-HP-ProBook-440-G7";
port := 10001;
DistributedWorker(host,port,MyFirstFunction);
