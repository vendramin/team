MyFirstFunction := function(t);
	System("sleep " cat IntegerToString(t));
	return "Hello Venus!";
end function;

host := "andrew-HP-ProBook-440-G7";
port := 10002;
DistributedWorker(host,port,MyFirstFunction);
