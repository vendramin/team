MyFirstFunction := function(t);
	System("sleep " cat IntegerToString(t));
	return "Hello World!";
end function;

host := "andrew-HP-ProBook-440-G7";
port := 10000;
DistributedWorker(host,port,MyFirstFunction);
