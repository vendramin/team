socket := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10000);

MySecondFunction := function(n);
	tasks := [1..n];
	output := DistributedManager(socket,tasks);
	for s in output do
		print s;
	end for;
	return "done";
end function;
