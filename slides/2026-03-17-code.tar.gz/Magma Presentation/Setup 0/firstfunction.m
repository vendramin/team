MyFirstFunction := function (t);
	System (" sleep " cat IntegerToString (t));
	return "Hello World !";
end function ;

MySecondFunction := function (n);
	for i in [1..n] do
		print MyFirstFunction (i);
	end for;
	return "done!";
end function ;
