177,1
A,GrpPerm,6,Length,Stabs,Ordaut,Type,Props,Id
