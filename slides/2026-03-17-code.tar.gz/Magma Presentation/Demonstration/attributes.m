freeze;

declare attributes GrpPerm: 
				Length,
				Stabs,
				Ordaut,
				Type,
				Props,
				Id;
