socketA := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10000);
socketB := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10001);
socketC := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10002);

Nmr_workers := 8;
SetLogFile ("logs/manager.log");

MySecondFunction := function(n);
	tt := Cputime ();

	tasks := [1..n];
	for i in [1..Nmr_workers] do
		command := "magma workerA.m > logs/workerA-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output1 := DistributedManager(socketA,tasks);
	for s in output1 do
		print s;
	end for;
	
	for i in [1..Nmr_workers] do
		command := "magma workerB.m > logs/workerB-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output2 := DistributedManager(socketB,tasks);
	for s in output2 do
		print s;
	end for;
	
	for i in [1..Nmr_workers] do
		command := "magma workerC.m > logs/workerC-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output3 := DistributedManager(socketC,tasks);
	for s in output3 do
		print s;
	end for;
	
	RESULTS := output1 cat output2 cat output3;
	
	System ("pgrep -f 'magma.*worker' | xargs -r kill -9 2>/dev/null || true");
	manager_time := Cputime (tt);
   	time_output := Pipe("grep -h 'Total time:' logs/work*-*.log | awk '{sum += $3} END {print sum}'", ""); 
   	total_time := eval StripWhiteSpace(time_output);
   	fprintf "results", "%o %.2o %o\n", "CPU time for manager is", manager_time, "seconds";
   	fprintf "results", "%o %.2o %o\n", "CPU time across all workers is", total_time, "seconds";
   	fprintf "results", "%o %.2o %o\n", "Total time is", manager_time + total_time, "seconds";
	PrintFile("results",RESULTS);
	
	return "done";
end function;
