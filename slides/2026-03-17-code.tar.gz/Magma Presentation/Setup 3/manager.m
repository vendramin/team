socket := Socket(: LocalHost := "andrew-HP-ProBook-440-G7", LocalPort := 10000);
Nmr_workers := 8;

MySecondFunction := function(n);
	tasks := [1..n];
	for i in [1..Nmr_workers] do
		command := "magma worker.m > worker-" cat IntegerToString(i) cat ".log &";
		System(command);
	end for;
	output := DistributedManager(socket,tasks);
	for s in output do
		print s;
	end for;
	return "done";
end function;
